#!/usr/bin/env node
/**
 * lint-descriptions.cjs
 *
 * Enforces the 100-char description budget for commands/gsd/*.md files.
 *
 * Usage:
 *   node scripts/lint-descriptions.cjs [file.md ...]
 *
 * If no args are given, scans commands/gsd/ automatically.
 * Exits 1 if any description exceeds 100 chars; exits 0 if all pass.
 */

'use strict';

const fs = require('fs');
const path = require('path');
const { ExitError, runMain } = require('./lib/cli-exit.cjs');
// The one frontmatter fence owner (src/frontmatter-fence.cts, built by build:lib).
// This dev-time script runs after the build (`npm run lint:descriptions`, the tests).
const { locateFrontmatterFence } = require('../gsd-core/bin/lib/frontmatter-fence.cjs');

const MAX_LENGTH = 100;
const COMMANDS_DIR = path.join(__dirname, '..', 'commands', 'gsd');

/**
 * Parse the description field from frontmatter in a .md file.
 * Returns null if no description is found.
 */
function parseDescription(content) {
  // The block is the one the one fence owner finds (found while implementing #5105).
  const fence = locateFrontmatterFence(content);
  if (!fence || !fence.closed) return null;
  const fm = content.slice(fence.openEnd, fence.bodyEnd);

  const quoted = fm.match(/^description:\s+"((?:[^"\\]|\\.)*)"\s*$/m);
  if (quoted) return quoted[1];

  const plain = fm.match(/^description:\s+(.+)$/m);
  if (plain) return plain[1].trim();

  return null;
}

function getFiles() {
  if (process.argv.length > 2) {
    return process.argv.slice(2);
  }
  return fs.readdirSync(COMMANDS_DIR)
    .filter(f => f.endsWith('.md'))
    .map(f => path.join(COMMANDS_DIR, f));
}

function main() {
  const files = getFiles();
  const violations = [];

  for (const filePath of files) {
    let content;
    try {
      content = fs.readFileSync(filePath, 'utf-8');
    } catch (err) {
      throw new ExitError(1, `ERROR: Cannot read file: ${filePath}\n  ${err.message}`);
    }

    const description = parseDescription(content);
    if (description === null) continue;

    if (description.length > MAX_LENGTH) {
      violations.push({ filePath, length: description.length, description });
    }
  }

  if (violations.length === 0) {
    const checked = files.length;
    process.stdout.write(`ok lint-descriptions: ${checked} file(s) checked, 0 violations\n`);
    return 0;
  }

  process.stderr.write(`\nERROR lint-descriptions: ${violations.length} violation(s) found\n\n`);
  for (const v of violations) {
    const preview = v.description.length > 120 ? v.description.slice(0, 117) + '...' : v.description;
    process.stderr.write(`  ${v.filePath}\n`);
    process.stderr.write(`    Length : ${v.length} (max ${MAX_LENGTH})\n`);
    process.stderr.write(`    Desc   : ${preview}\n\n`);
  }
  process.stderr.write(`Trim descriptions to <= ${MAX_LENGTH} chars. Flag docs belong in argument-hint:.\n\n`);
  return 1;
}

runMain(main);
